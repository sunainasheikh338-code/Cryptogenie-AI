package com.asheef.cryptogenie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptoGenieAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptoGenieAiApplication.class, args);
	}

}
