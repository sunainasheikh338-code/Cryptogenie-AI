package com.asheef.cryptogenie.model;

public enum TaskStatus {
    ACCEPTED, SUBMITTED, COMPLETED, OPEN
}
