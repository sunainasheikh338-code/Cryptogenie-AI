package com.asheef.cryptogenie.service;

import com.asheef.cryptogenie.dto.AdviceResponse;

public interface AdviceService {

    public AdviceResponse getAdvice(String symbol) ;
}
