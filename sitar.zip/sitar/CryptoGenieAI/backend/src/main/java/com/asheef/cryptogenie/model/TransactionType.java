package com.asheef.cryptogenie.model;

public enum TransactionType {
    DEPOSIT,WITHDRAW, ADMIN_REWARD, MINING, STAKE, UNSTAKE, TASK_REWARD, GAME_REWARD

}
